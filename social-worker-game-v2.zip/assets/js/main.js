/* ==========================================================================
   《是人，是工具？更是工具人！》──社工的勞動權益之路
   核心互動與劇本引擎
   ========================================================================== */

// ─── 背景圖片預載 ───
(function preloadAssets() {
    const assetsToPreload = [
        'assets/images/bg-office.webp',
        'assets/images/bg-corridor.webp',
        'assets/images/bg-dark.webp',
        'assets/images/ending-fallback.webp'
    ];
    assetsToPreload.forEach(src => {
        const img = new Image();
        img.src = src;
    });
})();

let state = {
    currentDay: 1,
    health: 100,
    avgHours: 8.0,
    salary: 38898,
    awaken: 0,
    evidence: [],
    log: []
};

let isTyping = false;
let typingTimer = null;

// ─── 蒐證物品圖鑑資料庫（修正 SVG xmlns 確保所有瀏覽器正常顯示） ───
const itemDatabase = {
    "職安忽視通聯紀錄": {
        title: "📁 職安忽視通聯紀錄",
        desc: "內含要求你單獨隻身涉險訪視酗酒案主的通聯紀錄。鋼鐵鐵證，能粉碎法庭上的狡辯。",
        icon: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23ef4444'><path d='M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6v-2h12v2zm0-3H6V7h12v2z'/></svg>"
    },
    "評鑑造假通聯紀錄": {
        title: "📜 評鑑造假通聯紀錄",
        desc: "主管強迫全員停擺直接服務、集體偽造文書應付外部評鑑指標的文字交辦通聯紀錄。",
        icon: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23f59e0b'><path d='M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z'/></svg>"
    },
    "工會法律支援聯盟": {
        title: "⚖️ 工會法律支援聯盟印信",
        desc: "向地方勞權工會幹部與法律顧問諮詢合約救濟、反擊薪資倒扣回捐的不當得利防禦契約。",
        icon: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2310b981'><path d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z'/></svg>"
    },
    "鋼鐵加班證據": {
        title: "⏱️ 鋼鐵加班公文截圖",
        desc: "從本機端加密匯出的伺服器登入日誌與真實打卡時數紀錄。是戳破機構假出勤單最鋒利的權益之矛。",
        icon: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%233b82f6'><path d='M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 2 22 6.48 22 12S17.52 2 11.99 2zm3.3 11.5L11 11V6h1.5v4.25l3.7 2.25-.71 1deg'/></svg>"
    },
    "職場霸凌錄音證阻": {
        title: "🎙️ 職場霸凌關鍵錄音軌",
        desc: "密錄主管在週會與內部群組施加冷暴力、斥責你缺乏熱忱與破壞團隊和諧的錄音音檔證據。",
        icon: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236366f1'><path d='M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.42 2.72 6.2 6 6.6V21h2v-3.4c3.28-.4 6-3.18 6-6.6h-1.7z'/></svg>"
    },
    "機構集體連署書": {
        title: "📜 機構基層夥伴連署連線書",
        desc: "頂住高壓排擠，集結全機構基層夥伴暗中蓋章按印的勞資爭議調解聯合抵抗陣線連署書。",
        icon: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23ec4899'><path d='M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z'/></svg>"
    }
};

// ─── 輔助函式：避免重複收集相同證據 ───
function addEvidence(itemName) {
    if (!state.evidence.includes(itemName)) {
        state.evidence.push(itemName);
    }
}

const tooltipEl = document.createElement('div');
tooltipEl.className = 'item-tooltip';
document.body.appendChild(tooltipEl);

document.addEventListener('mousemove', (e) => {
    if (tooltipEl.style.opacity === "1") {
        const offsetX = Math.min(e.clientX + 15, window.innerWidth - 260);
        const offsetY = Math.min(e.clientY + 15, window.innerHeight - 120);
        tooltipEl.style.left = offsetX + "px";
        tooltipEl.style.top = offsetY + "px";
    }
});

function typeWriter(text, targetId, callback) {
    isTyping = true;
    let currentStr = "";
    let i = 0;
    const container = document.getElementById(targetId);
    container.innerText = "";
    clearInterval(typingTimer);

    // 點擊對話框可立即跳過打字動畫，提升遊玩流暢度
    container.onclick = () => {
        if (isTyping) {
            clearInterval(typingTimer);
            container.innerText = text;
            isTyping = false;
            if (callback) callback();
        }
    };

    typingTimer = setInterval(() => {
        if (i < text.length) {
            currentStr += text.charAt(i);
            container.innerText = currentStr;
            i++;
        } else {
            clearInterval(typingTimer);
            isTyping = false;
            if (callback) callback();
        }
    }, 22);
}

// ─── 浮動數值提示引擎 ───
function floatText(text, type, e) {
    const el = document.createElement('div');
    el.className = 'floating-indicator';
    let icon = "⚙️ ";
    if (text.includes("健康") || text.includes("身心") || text.includes("創傷")) {
        icon = text.includes("▲") ? "💖 " : "🚑 ";
    } else if (text.includes("薪資") || text.includes("實拿") || text.includes("薪水")) {
        icon = text.includes("▲") ? "💵 " : "💸 ";
    } else if (text.includes("工會") || text.includes("自保") || text.includes("事證") || text.includes("鐵證")) {
        icon = "📁 ";
    } else if (text.includes("工時") || text.includes("行政")) {
        icon = text.includes("▼") ? "⏱️ " : "💥 ";
    } else if (text.includes("逆襲") || text.includes("反擊")) {
        icon = "🔥 ";
    }
    el.innerText = icon + text;
    if (type === 'down') el.style.color = '#ef4444';
    if (type === 'up') el.style.color = '#10b981';
    if (type === 'warn') el.style.color = '#f59e0b';

    const posX = e ? Math.min(Math.max(e.clientX - 60, 16), window.innerWidth - 240) : window.innerWidth / 2 - 80;
    const posY = e ? Math.max(e.clientY - 30, 20) : window.innerHeight / 2;
    el.style.left = `${posX}px`;
    el.style.top = `${posY}px`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2200);
}

function pushLog(txt) {
    state.log.unshift(`[第${state.currentDay}天] ${txt}`);
    const box = document.getElementById('logContent');
    if (box) {
        box.innerHTML = state.log.map(l => `<div>${l}</div>`).join('');
    }
}

function updateStatus() {
    document.getElementById('dayLabel').innerText = `第 ${state.currentDay} 天 / 30`;
    document.getElementById('healthLabel').innerText = `${state.health}%`;
    document.getElementById('hoursLabel').innerText = `${state.avgHours.toFixed(1)}h`;
    document.getElementById('salaryLabel').innerText = `$${state.salary.toLocaleString()}`;
    document.getElementById('bagCount').innerText = `${state.evidence.length}`;

    const healthFill = document.getElementById('healthFill');
    if (healthFill) {
        healthFill.style.width = `${state.health < 0 ? 0 : state.health}%`;
        if (state.health < 35) healthFill.style.backgroundColor = 'var(--color-danger)';
        else if (state.health < 65) healthFill.style.backgroundColor = 'var(--color-warning)';
        else healthFill.style.backgroundColor = 'var(--color-success)';
    }

    const workPercentage = (state.avgHours / 24) * 100;
    const pieChart = document.getElementById('pieChart');
    if (pieChart) {
        let pieColor = 'var(--color-warning)';
        if (state.avgHours > 10) pieColor = 'var(--color-danger)';
        else if (state.avgHours > 8.5) pieColor = 'var(--color-warning)';
        pieChart.style.background = `conic-gradient(${pieColor} 0% ${workPercentage}%, rgba(0,0,0,0.08) ${workPercentage}% 100%)`;
    }

    // ─── 蒐證背包動態渲染 ───
    const bag = document.getElementById('bagContent');
    if (bag) {
        bag.innerHTML = '';
        if (state.evidence.length === 0) {
            bag.innerHTML = `<div class="bag-empty-hint">[ 🔍 暗中留意並搜集主管不合理業務交辦事證，裝滿此格子欄位... ]</div>`;
        } else {
            state.evidence.forEach(itemName => {
                const itemData = itemDatabase[itemName];
                if (itemData) {
                    const slot = document.createElement('div');
                    slot.className = 'bag-slot';
                    const iconEl = document.createElement('div');
                    iconEl.className = 'bag-icon';
                    iconEl.style.backgroundImage = `url("${itemData.icon}")`;
                    slot.appendChild(iconEl);

                    slot.onmouseenter = () => {
                        tooltipEl.innerHTML = `<div class="item-tooltip-title">${itemData.title}</div><div>${itemData.desc}</div>`;
                        tooltipEl.style.opacity = "1";
                    };
                    slot.onmouseleave = () => {
                        tooltipEl.style.opacity = "0";
                    };
                    // 支援手機點擊顯示道具說明
                    slot.onclick = (e) => {
                        e.stopPropagation();
                        tooltipEl.innerHTML = `<div class="item-tooltip-title">${itemData.title}</div><div>${itemData.desc}</div>`;
                        tooltipEl.style.left = Math.min(e.clientX + 10, window.innerWidth - 250) + "px";
                        tooltipEl.style.top = Math.min(e.clientY + 10, window.innerHeight - 120) + "px";
                        tooltipEl.style.opacity = "1";
                        setTimeout(() => { tooltipEl.style.opacity = "0"; }, 2600);
                    };
                    bag.appendChild(slot);
                }
            });
            const totalSlots = Math.max(4, state.evidence.length);
            for (let k = state.evidence.length; k < totalSlots; k++) {
                const emptySlot = document.createElement('div');
                emptySlot.className = 'bag-slot';
                bag.appendChild(emptySlot);
            }
        }
    }

    const phaseLabel = document.getElementById('phaseLabel');
    if (phaseLabel) {
        if (state.currentDay <= 10) phaseLabel.innerText = "意識覺醒";
        else if (state.currentDay <= 20) phaseLabel.innerText = "證據蒐集";
        else phaseLabel.innerText = "採取行動";
    }

    const body = document.getElementById('gameBody');
    if (body) {
        if (state.health < 35) {
            body.classList.add('dizzy-mode');
            document.getElementById('healthLabel').style.color = 'var(--color-danger)';
        } else {
            body.classList.remove('dizzy-mode');
            document.getElementById('healthLabel').style.color = 'var(--color-success)';
        }
        if (state.health < 20) body.classList.add('danger-border');
        else body.classList.remove('danger-border');
    }

    let grayscaleValue = (100 - state.health) / 100;
    if (grayscaleValue > 1) grayscaleValue = 1;
    if (grayscaleValue < 0) grayscaleValue = 0;
    document.body.style.filter = `grayscale(${grayscaleValue})`;
}

// ─── 30天核心劇本事件庫 ───
const timelineEvents = {
    1: {
        speaker: "機構執行長 🧑‍💼",
        text: "社會局撥款年底才下來，大家每個月『樂捐』 3,000 元回人事公積金維持機構現金流。這在方案管理上叫共體時艱。你是助人專業者，相信你能理解機構永續經營才能守護案主吧？",
        options: [
            {
                text: "含淚簽署『自願捐款同意書』以維持雇傭關係 ✍️",
                resolve: (e) => {
                    state.salary -= 3000;
                    state.health -= 20;
                    floatText("實拿薪資低於法定基準 ▼", "down", e);
                    floatText("專業尊嚴受挫 ▼", "down", e);
                    pushLog("被迫簽署違反衛福部勞動基準之薪資回捐同意書。");
                    nextStep();
                }
            },
            {
                text: "引用《社工師法》與衛福部嚴禁回捐條款委婉拒絕 ❌",
                resolve: (e) => {
                    state.avgHours += 1.5;
                    state.health -= 15;
                    floatText("案量分配管理權限懲罰 ▲", "warn", e);
                    pushLog("嚴拒回捐。隨後在管理考核中，被主管以『團隊配合度低』為由指派大量高風險保護個案。");
                    nextStep();
                }
            }
        ]
    },
    3: {
        speaker: "督導 🧓",
        text: "有案主家屬向1999投訴，不滿你評估案主不符合急難救助金補助資格，指責你缺乏同理心。社會局承辦要求機構說明。你今天下班前交一份三千字『個案處遇評估精進與專業關係檢討報告』，不然會嚴重影響機構的評鑑。",
        options: [
            {
                text: "落入防衛性文書地獄，加班完成防責報告 📑",
                resolve: (e) => {
                    state.health -= 15;
                    state.avgHours += 2.5;
                    floatText("行政耗能工時飆升 ▲", "warn", e);
                    pushLog("耗費大量時間撰寫符合評鑑指標的行政防責報告，身心過勞。");
                    nextStep();
                }
            },
            {
                text: "引用倫理守則，檢附詳實處遇紀錄與經濟評估工具自清 ✉️",
                resolve: (e) => {
                    state.health -= 10;
                    addEvidence("評鑑造假通聯紀錄");
                    floatText("倫理自保事證 ▲", "up", e);
                    pushLog("堅持專業倫理評估，留下符合《社工倫理守則》的嚴謹文書鐵證。");
                    nextStep();
                }
            }
        ]
    },
    5: {
        speaker: "社會局核銷承辦 📋",
        text: "你上個月報支的弱勢案主家庭訪視交通差旅費被退件了。局裡承辦人員基於防弊要求，你必須重新補件補上『個案隱私大門牌與你公務機車車牌同框的清晰佐證照』。督導雙手一攤，表示公部門核銷規定就是這樣，要你自己想辦法。",
        options: [
            {
                text: "自吞車資差旅費，直接放棄核銷以節省行政耗能 💸",
                resolve: (e) => {
                    state.salary -= 500;
                    state.health -= 10;
                    floatText("實拿薪資再度短少 ▼", "down", e);
                    pushLog("因公部門核銷防弊機制，被迫自貼差旅費。");
                    nextStep();
                }
            },
            {
                text: "前往個案家大門口拍照補件，承受破壞專業信任關係的倫理風險 📸",
                resolve: (e) => {
                    state.health -= 20;
                    floatText("專業尊嚴受挫 ▼", "down", e);
                    pushLog("為了幾百塊去拍個案家門牌，嚴重損害專業信任關係。");
                    nextStep();
                }
            }
        ]
    },
    8: {
        speaker: "資深同事 🧑‍🦳",
        text: "下週社會局委託方案的外部評鑑委員要到機構進行實地訪查了！執行長下令這幾天個案直接服務全部暫停，全員留下來偽造日常活動成果冊、修改個案紀錄日誌以符合KPI，週六還要全員無薪來辦公室佈置會場。這叫方案品質控管啦！",
        options: [
            {
                text: "配合行政管理演戲，留下來集體製造評鑑成果 📕",
                resolve: (e) => {
                    state.health -= 15;
                    state.avgHours += 2.0;
                    floatText("專業異化與精神消耗 ▲", "warn", e);
                    pushLog("被迫配合機構進行評鑑文書美化，專業助人初衷嚴重異化。");
                    nextStep();
                }
            },
            {
                text: "拒絕偽造紀錄，暗中截圖並留存機構要求造假之行政交辦證據 📱",
                resolve: (e) => {
                    state.health -= 10;
                    addEvidence("評鑑造假通聯紀錄");
                    floatText("機構造假鐵證入庫 ▲", "up", e);
                    pushLog("搜集機構管理階層要求員工美化評鑑指標之核心通聯。");
                    nextStep();
                }
            }
        ]
    },
    11: {
        speaker: "督導 🧓",
        text: "下午你需要單獨前往高風險家庭，訪視那名曾有酗酒鬧事、酒後嚴重暴力砸屋傾向的酗酒案主。機構目前經費有限，沒有配發防狼噴霧喔，帶防具會破壞與個案的專業信任關係！你自己多注意點、機靈點就好。",
        options: [
            {
                text: "隻身前往：在毫無個人職安防護下，硬著頭皮前往高風險現場訪視 🛵",
                resolve: (e) => {
                    state.health -= 35;
                    floatText("替代性創傷與驚嚇 ▼", "down", e);
                    pushLog("隻身一人涉險家訪，遭到酗酒案主砸毀家具恐嚇，在毫無防具支援下驚險逃出。");
                    nextStep();
                }
            },
            {
                text: "【💡 文字回鎖】答應前往，但隨即在公務群組回覆：『已遵照督導指示隻身前往訪視酗酒暴力個案。』 📱",
                resolve: (e) => {
                    state.health -= 10;
                    addEvidence("職安忽視通聯紀錄");
                    floatText("個人自保事證入庫 ▲", "up", e);
                    pushLog("運用文字確認技巧，強迫管理層在群組留下漠視員工職安之文字鐵證。");
                    nextStep();
                }
            }
        ]
    },
    14: {
        speaker: "人事主管 👩‍💻",
        text: "恭喜你通過專技高考取得社工師證照！不過因為政府補助方案編列的專業人員職缺有限，機構目前無法調整你的薪資級卡、也無法給予每月 $4,000 的社工師執照加給喔。不過既然你考到了，以後法律訴訟個案的專業法庭報告就由你全權負責囉！",
        options: [
            {
                text: "默默認命，在勞動條件不對等下承擔更重的法律責任 😮‍💨",
                resolve: (e) => {
                    state.health -= 20;
                    floatText("身心消耗 ▼", "down", e);
                    pushLog("工作責任加重，助人待遇完全原地踏步。");
                    nextStep();
                }
            },
            {
                text: "將不符合衛福部薪資基準之勞動契約事證祕密傳給地方社工職業工會諮詢 ✊",
                resolve: (e) => {
                    addEvidence("工會法律支援聯盟");
                    floatText("權益覺醒 ▲", "up", e);
                    pushLog("向工會尋求勞檢律師的專業保障評估。");
                    nextStep();
                }
            }
        ]
    },
    17: {
        speaker: "內心獨白 🧠",
        text: "長期面對保護性重案的負面情緒、道德勒索與不合理的行政核銷，你出現了嚴重的替代性創傷，晚上焦慮失眠且一踏進機構手就不自覺發抖。此時，地方社工職業工會正好提供了外部心理喘息與法律權益諮商資源...",
        options: [
            {
                text: "拒絕求助，繼續消耗殘存的身心能量以應付公文進度 💻",
                resolve: (e) => {
                    state.health -= 25;
                    floatText("慢性替代性創傷重創 ▼", "down", e);
                    pushLog("選擇硬撐，替代性創傷持續慢性吞噬續航力。");
                    nextStep();
                }
            },
            {
                text: "請假參與工會的外部喘息服務，落實自我照顧（Self-Care）原則 🧘",
                resolve: (e) => {
                    state.health = Math.min(100, state.health + 25);
                    state.avgHours += 2.0;
                    floatText("身心能量回補 ▲", "up", e);
                    floatText("積壓工作被迫半夜補回 ▼", "warn", e);
                    pushLog("花時間照顧自己，心靈得到修補，但積壓的工作被迫半夜瘋狂加班補回。");
                    nextStep();
                }
            }
        ]
    },
    20: {
        speaker: "督導 🧓",
        text: "這個月你為了應付社會局方案進度天天自主加班到深夜。督導在下班前口頭告知：『我們機構沒有加班費編列預算喔，一律轉補休。共體時艱啦！』但你心裡很清楚，案量爆炸下，依照社會工作管理常態，這些補休月底期限一到就會直接過期流失。",
        options: [
            {
                text: "默默接受，默許機構管理層對不給付加班費的違法常態 😮‍💨",
                resolve: (e) => {
                    state.health -= 10;
                    pushLog("接受補休方案（該補休將在月底因案量爆炸而流失）。");
                    nextStep();
                }
            },
            {
                text: "表面答應轉補休，但暗中落實並下載打卡紀錄與紀錄系統登入日誌 💾",
                resolve: (e) => {
                    state.health -= 5;
                    addEvidence("鋼鐵加班證據");
                    floatText("出勤鐵證入庫 ▲", "up", e);
                    pushLog("暗中搜集扎實的出勤證明日誌。");
                    nextStep();
                }
            }
        ]
    },
    22: {
        speaker: "執行長 🧑‍💼",
        text: "勞動檢查員下週要來機構進行專案勞檢了！主管私下塞給你一份完美版的『符合法定工時出勤紀錄表』，上面寫著每天 17:30 準時打卡下班：『勞檢問的時候配合一下，就說大家都沒加班，這是為了機構的社會聲譽！』",
        options: [
            {
                text: "配合演戲：屈服於管理層規訓，在虛假出勤表上簽名確認 🤥",
                resolve: (e) => {
                    state.health -= 15;
                    floatText("專業倫理操守受挫 ▼", "down", e);
                    pushLog("向機構屈服，被迫協助機構偽造文書應付勞檢，深陷倫理與法律兩難。");
                    nextStep();
                }
            },
            {
                text: "【💡 軌跡保全】表面不爭吵，但暗中導出本機端的個案系統登入日誌（Log）直接塞給勞檢員 📁",
                resolve: (e) => {
                    state.health -= 20;
                    addEvidence("鋼鐵加班證據");
                    floatText("個人數位軌跡保全 ▲", "up", e);
                    pushLog("不與主管正面衝突，默默保全數位出勤紀錄日誌，給予假出勤單反擊。");
                    nextStep();
                }
            }
        ]
    },
    24: {
        speaker: "內心獨白 🧠",
        text: "自從你在勞檢中拒絕配合演戲，機構管理層開始在辦公室對你進行嚴重的職場冷暴力與孤立。主管將大量陳年死角爛帳個案全數塞給你，並在週會公開影射你『缺乏大愛、自私自利、破壞團隊和諧』。高壓的敵意環境讓你每天踏進辦公室都產生強烈的生理嘔吐感...",
        options: [
            {
                text: "默默隱忍，每天吞下職場集體霸凌的精神內耗 😮‍💨",
                resolve: (e) => {
                    state.health -= 20;
                    floatText("精神內耗加劇 ▼", "warn", e);
                    pushLog("隱忍職場霸凌，精神內耗嚴重消耗。");
                    nextStep();
                }
            },
            {
                text: "落實風險管理，全面錄音搜集主管刁難之職場霸凌事證 🎙️",
                resolve: (e) => {
                    state.health -= 10;
                    addEvidence("職場霸凌錄音證阻");
                    floatText("反擊準備 ▲", "up", e);
                    pushLog("秘密錄音，收集主管冷暴力的職場霸凌鐵證。");
                    nextStep();
                }
            },
            {
                text: "【🔥 證據反制】拿出前天備忘的造假評鑑紀錄，微笑約談主管",
                resolve: (e) => {
                    if (state.evidence.includes("評鑑造假通聯紀錄")) {
                        state.health = Math.min(100, state.health + 15);
                        floatText("逆襲主管成功 ▲", "up", e);
                        pushLog("引用造假事證反威脅，迫使主管暫時收斂排擠冷暴力。");
                        nextStep();
                    } else {
                        alert("系統：你的蒐證物品欄中缺乏『評鑑造假通聯紀錄』，無法啟動此反制選項！");
                    }
                }
            }
        ]
    },
    26: {
        speaker: "督導 🧓",
        text: "這週週六晚上 10 點你正在放假休息，突然接到個案打來的求助電話。與此同時，督導在 LINE 群組 Tag 你：『社工要有大愛與熱忱，個案現在最需要你，請立刻協助處理。』",
        options: [
            {
                text: "立刻開電腦被迫回歸工作狀態處理個案 ⌨️",
                resolve: (e) => {
                    state.avgHours += 1.5;
                    state.health -= 15;
                    floatText("公私界線破裂工時暴增 ▲", "warn", e);
                    pushLog("犧牲休假時間，被迫在深夜進行無給職勞動。");
                    nextStep();
                }
            },
            {
                text: "【🔥 倫理 Reframing】回覆督導：『依職安法規定，缺乏安全防護與合理出勤補償之疲勞勞動將危及案主權益，本案留待週一依專業程序緊急處置。』",
                resolve: (e) => {
                    state.health -= 25;
                    floatText("面臨巨大道德指責 ▼", "down", e);
                    pushLog("週一上班被主管痛罵『沒有社會責任、草菅人命』。");
                    nextStep();
                }
            }
        ]
    },
    28: {
        speaker: "資深同事 🧑‍🦳",
        text: "你試圖在機構內串聯其他夥伴集體向工會舉報不合理回捐與薪資短少。資深同事拉住你：『不要把事情鬧大，如果機構被社會局撤銷補助倒閉了，那些被安置的小孩要去哪裡？』",
        options: [
            {
                text: "內心動搖，決定退出放棄集體串聯 🛑",
                resolve: (e) => {
                    pushLog("在道德勒索與同儕壓力下放棄集體發聲。");
                    nextStep();
                }
            },
            {
                text: "頂住排擠與集體道德勒索，說服夥伴一起祕密留存連署書 📜",
                resolve: (e) => {
                    state.health -= 20;
                    addEvidence("機構集體連署書");
                    floatText("集體防禦解鎖 ▲", "up", e);
                    pushLog("成功頂住壓力，拿到了集體抵抗的關鍵連署。");
                    nextStep();
                }
            },
            {
                text: "【🔥 邏輯粉碎】拿出職安通聯鐵證：『連社工的安全都保護不了，遑論保護小孩！』",
                resolve: (e) => {
                    if (state.evidence.includes("職安忽視通聯紀錄")) {
                        state.health = Math.min(100, state.health + 10);
                        addEvidence("機構集體連署書");
                        floatText("徹底粉碎情緒勒索 ▲", "up", e);
                        pushLog("用職安鐵證全面粉碎同儕的集體道德規訓，全體社工100%同意參與抗爭連署！");
                        nextStep();
                    } else {
                        alert("系統：你的蒐證物品欄中缺乏『職安忽視通聯紀錄』，無法啟動此反制選項！");
                    }
                }
            }
        ]
    },
    29: {
        speaker: "工會法律顧問 ✊",
        text: "到了月底結算關頭。明天就是最後一天的爭議調解，看著手頭上收集到的各種體制違法事證與千瘡百孔的身心，你決定如何向這個僵化、披著大愛外衣剝削專業的社福管理環境發出怒吼？",
        options: [
            {
                text: "選擇吞下去，默默把證據銷毀繼續當聽話的齒輪 ⚙️",
                resolve: () => {
                    endGame("wheel");
                }
            },
            {
                text: "啟動三管齊下合法抗爭：結合證據向衛福部平臺舉報並向勞工局申請爭議調解 ⚖️",
                resolve: () => {
                    if (state.evidence.includes("機構集體連署書") && state.evidence.length >= 3) {
                        endGame("good");
                    } else {
                        endGame("burnout");
                    }
                }
            }
        ]
    }
};

const continuousDamages = [
    "司法寒蟬效應籠罩。為了避免『被推出去上銬入獄』，你今天花了 6 個小時雕琢 3000 字的防責防衛性報告。✍️",
    "中央線上申報系統今天大當機，轉圈圈轉了兩小時後無預警自動登出，剛寫好的個案紀錄全部消失。😭",
    "為了應付下週的外部評鑑，督導要求全機構業務停擺，大家一起瘋狂製造精美的假日常活動成果冊。📕",
    "今天被不理性的個案家屬在電話中用三字經連續痛罵了半小時，你發現你花在防責文字的時間，遠超於真正陪伴個案。🤬"
];

function showTutorial() {
    document.getElementById('homeScreen').classList.add('hidden');
    document.getElementById('tutorialScreen').classList.remove('hidden');
    document.getElementById('gameBgLayer').style.backgroundImage = "url('assets/images/bg-office.webp')";
}

function startGame() {
    document.getElementById('tutorialScreen').classList.add('hidden');
    document.getElementById('gamePlayScreen').classList.remove('hidden');
    triggerEvent(1);
}

function triggerEvent(day) {
    updateStatus();
    if (state.health <= 0) {
        endGame("collapse");
        return;
    }

    const bgLayer = document.getElementById('gameBgLayer');
    if (bgLayer) {
        if (day <= 10) {
            bgLayer.style.backgroundImage = "url('assets/images/bg-office.webp')";
        } else if (day <= 20) {
            bgLayer.style.backgroundImage = "url('assets/images/bg-corridor.webp')";
        } else {
            bgLayer.style.backgroundImage = "url('assets/images/bg-dark.webp')";
        }
    }

    const inlineCal = document.getElementById('inlineCalendar');
    if (inlineCal) {
        inlineCal.classList.remove('flip-anim');
        void inlineCal.offsetWidth;
        inlineCal.classList.add('flip-anim');
        document.getElementById('calendarDayLabel').innerText = day < 10 ? `0${day}` : day;
    }

    if (timelineEvents[day]) {
        const ev = timelineEvents[day];
        document.getElementById('speakerTag').innerText = ev.speaker;
        typeWriter(ev.text, 'dialogueText', () => {
            const container = document.getElementById('optionsContainer');
            container.innerHTML = '';
            ev.options.forEach(opt => {
                const btn = document.createElement('button');
                btn.className = 'option-btn';
                btn.innerText = opt.text;
                btn.onclick = (e) => {
                    if (!isTyping) opt.resolve(e);
                };
                container.appendChild(btn);
            });
        });
    } else {
        showOverlay();
    }
}

function showOverlay() {
    const idx = Math.floor(Math.random() * continuousDamages.length);
    document.getElementById('speakerTag').innerText = "日常血汗消耗";
    state.health -= 3;
    updateStatus();
    if (state.health <= 0) {
        endGame("collapse");
        return;
    }

    const mainText = continuousDamages[idx] + "

⏱️ 【日常時間配置】今天高壓案量依舊，下班前的核心空檔你決定拿來做什麼？";

    typeWriter(mainText, 'dialogueText', () => {
        const container = document.getElementById('optionsContainer');
        container.innerHTML = '';

        const opt1 = document.createElement('button');
        opt1.className = 'option-btn';
        opt1.innerText = "🚗 密集家訪並狂補『防衛性處遇紀錄』以防出事（平均工時 ▼ 0.4h / 健康度 ▼ 3%）";
        opt1.onclick = (e) => {
            if (isTyping) return;
            state.avgHours = Math.max(8.0, state.avgHours - 0.4);
            state.health -= 3;
            floatText("防責文書進度推進 ▲", "up", e);
            floatText("肉體勞累消耗 ▼", "down", e);
            nextStep();
        };

        const opt2 = document.createElement('button');
        opt2.className = 'option-btn';
        opt2.innerText = "📝 參與專業進修，改善個案處遇與方案品質（每月實拿薪資 ▲ $450 / 健康度 ▼ 2%）";
        opt2.onclick = (e) => {
            if (isTyping) return;
            state.salary += 450;
            state.health -= 2;
            floatText("專業知能與方案品質 ▲", "up", e);
            floatText("研習精神內耗 ▼", "down", e);
            nextStep();
        };

        const opt3 = document.createElement('button');
        opt3.className = 'option-btn';
        opt3.innerText = "🧘 用工會喘息資源請假看諮商（身心健康度 ▲ 8% / 工時 ▲ 0.5h）";
        opt3.onclick = (e) => {
            if (isTyping) return;
            state.health = Math.min(100, state.health + 8);
            state.avgHours += 0.5;
            floatText("替代性創傷得到修補 ▲", "up", e);
            floatText("積壓公文與連帶罪惡感 ▼", "warn", e);
            nextStep();
        };

        container.appendChild(opt1);
        container.appendChild(opt2);
        container.appendChild(opt3);
    });
}

function nextStep() {
    state.currentDay++;
    if (state.currentDay > 30) {
        endGame("resign");
    } else {
        triggerEvent(state.currentDay);
    }
}

// ─── 結算判定與結局畫面（已修復 Unsplash 圖片網址與本地備援圖） ───
function endGame(endingType) {
    document.getElementById('gamePlayScreen').classList.add('hidden');
    document.getElementById('endingScreen').classList.remove('hidden');
    document.body.style.filter = "none";
    document.body.classList.remove('dizzy-mode', 'danger-border');
    document.body.style.backgroundColor = "#ede3d4";

    document.getElementById('endSalary').innerText = `$${state.salary.toLocaleString()}`;
    document.getElementById('endHours').innerText = `${state.avgHours.toFixed(1)} 小時 / 天`;
    document.getElementById('endHealth').innerText = `${state.health < 0 ? 0 : state.health}%`;

    const title = document.getElementById('endingTitle');
    const narration = document.getElementById('endingNarration');
    const avatar = document.getElementById('endingAvatar');

    const unPrefix = "https://images.unsplash.com/";
    const unSuffix = "?auto=format&fit=crop&w=800&q=80";

    if (endingType === 'collapse' || state.health <= 0) {
        title.innerText = "【Ending E-5 🚑 BAD ENDING：倒在辦公桌前的慢性燃燒殆盡】";
        title.className = "ending-title bad";
        avatar.style.backgroundImage = `url('${unPrefix}photo-1618005182384-a83a8bd57fbe${unSuffix}'), url('assets/images/bg-office.webp')`;
        narration.innerText = "你默默燃燒了自己，直到健康歸零。當你倒下送往醫院時，機構的齒輪依然冷酷地在轉動，明天就會有下一個新人進來填補空缺。別讓大愛成為剝削的遮羞布。";
    } else if (endingType === 'wheel') {
        title.innerText = "【Ending D-4 ⚙️ BAD ENDING：體制內的乖順無薪血汗齒輪】";
        title.className = "ending-title bad";
        avatar.style.backgroundImage = `url('${unPrefix}photo-1508962914676-134849a727f0${unSuffix}'), url('assets/images/bg-corridor.webp')`;
        narration.innerText = "你選擇了全盤隱忍。薪水被強迫回捐、每日被迫無薪自主加班，身體與精神逐漸變得千瘡百孔。然而，正是你的默默承受，滋養了黑心體制繼續剝削下一代社工的溫床。";
    } else if (endingType === 'good' || (state.evidence.includes("機構集體連署書") && state.evidence.length >= 3)) {
        title.innerText = "【Ending A-1 ⚖️ TRUE GOOD ENDING：勞權覺醒的鋼鐵自保者】";
        title.className = "ending-title good";
        avatar.style.backgroundImage = `url('${unPrefix}photo-1517486808906-6ca8b3f04846${unSuffix}'), url('assets/images/ending-fallback.webp')`;
        narration.innerText = "精準行政技術的全面逆襲！在勞資爭議調解庭上，你掏出過去 30 天秘密備忘的出勤 Log 與群組通聯，當場把執行長問到啞口無言。勞動局當場裁定機構非法倒扣回捐與未給付加班費，強迫執行長簽字將私吞的薪資與加班費（總計 7 萬多元）全額吐還、直接匯入你的帳戶！不靠遠大口號，基層個人靠嚴謹的行政證據一樣能拿回尊嚴！";
    } else if (state.salary > 45000) {
        title.innerText = "【Ending B-2 📚 GOOD ENDING：瘋狂研習的黃金跳槽專業戶】";
        title.className = "ending-title good";
        avatar.style.backgroundImage = `url('${unPrefix}photo-1522202176988-66273c2fd55f${unSuffix}'), url('assets/images/ending-fallback.webp')`;
        narration.innerText = "這是『狂研習策略』的終極勝利！你把日常空檔全部拿來進行外部進修。主管以為你是在幫機構共體時艱，天天壓榨你，卻不知道你是在用公務時間刷滿自己的高階履歷。月底到了，你帶著滿滿的高階社工證照直接遞出辭呈，跳槽去另一家大型旗艦型 NPO，起薪當場翻倍暴漲！";
    } else {
        title.innerText = "【Ending C-3 🧘 NORMAL ENDING：精準防禦的職場喘息大師】";
        title.className = "ending-title";
        avatar.style.backgroundImage = `url('${unPrefix}photo-1522071820081-009f0129c71c${unSuffix}'), url('assets/images/bg-dark.webp')`;
        narration.innerText = "這是『狂請假與精準自我照顧』的隱蔽勝利。你天天準時下班、家訪完紀錄補完立刻走人。主管在背後斥責你『缺乏熱忱』，你直接已讀不回，轉頭請假去看諮商。月底到了，你的身心健全，多了一個快樂的普通人。祝福你轉行順利！";
    }
}

// ─── 結算成就卡截圖下載功能（已修復 html2canvas CDN 與跨域設定） ───
function downloadCard() {
    const card = document.getElementById('captureArea');
    if (typeof html2canvas === 'undefined') {
        alert("截圖元件尚未載入完成，請確認網路連線後再試一次，或使用瀏覽器內建截圖功能！");
        return;
    }

    html2canvas(card, {
        useCORS: true,
        allowTaint: false,
        scale: 2,
        backgroundColor: "#fcfaf7"
    }).then(canvas => {
        const link = document.createElement('a');
        link.download = '社工勞權爭取模擬器_結算成就卡.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
    }).catch(err => {
        alert("截圖生成失敗，建議直接使用手機或電腦的螢幕截圖功能保存！
（錯誤原因：外部圖片跨域限制）");
        console.error(err);
    });
}
